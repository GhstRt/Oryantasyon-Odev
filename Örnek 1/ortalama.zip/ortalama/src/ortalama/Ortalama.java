package ortalama;

import java.util.Scanner;

/**
 *
 * @author ghost
 */
public class Ortalama {
    public static void main(String[] args) {
        
        Scanner giris = new Scanner(System.in);
        int not = 0;
        
        for (int i = 0; i<200; i++){
            System.out.print("Ogrencinin Notunu Giriniz: ");
            not += giris.nextInt();
        }
        
        int Ortalama = not / 200;
        System.out.println(Ortalama);
    }
    
}
