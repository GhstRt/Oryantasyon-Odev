package pozitifnegatif;

import java.util.Scanner;

/**
 *
 * @author ghost
 */
public class PozitifNegatif {

    public static void main(String[] args) {
        Scanner giris = new Scanner(System.in);
        
        System.out.print("Bir Sayi Giriniz: ");
        int sayi = giris.nextInt();
        
        if (sayi > 0){
            System.out.println("Sayi Pozitif");
        }
        else if (sayi == 0){
            System.out.println("Sayi Sifira Esit");
        }
        else {
            System.out.println("Sayi Negatif");
        }
    }
    
}
