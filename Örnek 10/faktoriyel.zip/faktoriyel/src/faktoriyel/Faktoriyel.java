package faktoriyel;

import java.util.Scanner;

/**
 *
 * @author ghost
 */
public class Faktoriyel {

    public static void main(String[] args) {
        Scanner giris =  new Scanner(System.in);
        int faktoriyel = 1;
        
        System.out.print("Sayi Giriniz: ");
        int sayi = giris.nextInt();
        
        while(sayi>1){
            faktoriyel = faktoriyel * sayi;
            sayi--;
        }
        
        System.out.println(faktoriyel);
    }
    
}
