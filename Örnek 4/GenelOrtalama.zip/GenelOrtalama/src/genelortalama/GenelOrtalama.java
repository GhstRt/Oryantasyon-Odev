package genelortalama;

import java.util.Scanner;

/**
 *
 * @author ghost
 */
public class GenelOrtalama {

    public static void main(String[] args) {
        Scanner giris = new Scanner(System.in);
        
        System.out.print("Vize Notunuzu Giriniz: ");
        float vize = giris.nextFloat();
        System.out.print("Final Notunuzu Gİriniz: ");
        float Final = giris.nextFloat();
        
        int GnlOrt = (int) ((vize*0.4)+(Final*0.6));
        System.out.println(GnlOrt);
    }
    
}
