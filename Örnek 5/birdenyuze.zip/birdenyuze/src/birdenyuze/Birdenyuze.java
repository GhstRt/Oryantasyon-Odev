package birdenyuze;

/**
 *
 * @author ghost
 */
public class Birdenyuze {

    public static void main(String[] args) {
        int toplam = 0;
        
        for (int i = 0; i<100; i++){
            toplam = toplam + i;
        }
        
        System.out.println(toplam);
    }
    
}
