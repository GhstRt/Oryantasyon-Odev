package tekcift;

import java.util.Scanner;

/**
 *
 * @author ghost
 */
public class TekCift {

    public static void main(String[] args) {
        Scanner giris = new Scanner(System.in);
        
        System.out.print("Bir Sayi Giriniz: ");
        int sayi = giris.nextInt();
        
        if (sayi % 2 > 0){
            System.out.println("Sayi Tek");
        }
        else {
            System.out.println("Sayi Cift");
        }
    }  
}
