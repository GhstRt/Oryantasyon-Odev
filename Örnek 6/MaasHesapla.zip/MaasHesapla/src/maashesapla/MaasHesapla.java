package maashesapla;

import java.util.Scanner;

/**
 *
 * @author ghost
 */
public class MaasHesapla {

    public static void main(String[] args) {
        Scanner giris = new Scanner(System.in);
        
        System.out.print("Calisma Saatini Giriniz: ");
        int calisma_saat = giris.nextInt();
        System.out.print("Saatlik Ucreti Giriniz: ");
        int saatlik_ucret = giris.nextInt();
        
        int maas = calisma_saat*saatlik_ucret;
        System.out.println(maas);
    }
    
}
