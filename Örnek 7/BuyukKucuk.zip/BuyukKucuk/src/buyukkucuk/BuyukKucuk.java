package buyukkucuk;

import java.util.Scanner;

/**
 *
 * @author ghost
 */
public class BuyukKucuk {

    public static void main(String[] args) {
        Scanner giris = new Scanner(System.in);
        
        System.out.print("1. Sayiyi Giriniz: ");
        int sayi1 = giris.nextInt();
        System.out.print("2. Sayiyi Giriniz: ");
        int sayi2 = giris.nextInt();
        
        if (sayi1 > sayi2){
            System.out.println("Sayi1 Buyuk");
        }
        else{
            System.out.println("Sayi2 Buyuk");
        }
    }
    
}
