package boykilo;

import java.util.Scanner;

/**
 *
 * @author ghost
 */
public class BoyKilo {

    public static void main(String[] args) {
        Scanner giris = new Scanner(System.in);
        
        System.out.print("Boyunuzu Giriniz: ");
        float Boy = giris.nextFloat();
        System.out.print("Kilonuzu Giriniz: ");
        int Kilo = giris.nextInt();
        
        float endeks = Kilo / (Boy*Boy);
        System.out.println(endeks);
    }
    
}
